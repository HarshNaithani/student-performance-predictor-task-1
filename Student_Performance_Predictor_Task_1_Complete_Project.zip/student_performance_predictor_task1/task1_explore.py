"""
Project 1 - Student Performance Predictor
Task 1 - Load and Explore the Data

This task creates/loads a small dataset containing Hours Studied and Exam Score,
then explores its structure, missing values, and basic statistics.
"""

from pathlib import Path
import pandas as pd
import matplotlib.pyplot as plt


ROOT = Path(__file__).resolve().parent
DATA_FILE = ROOT / "data" / "student_performance.csv"
OUTPUT_DIR = ROOT / "outputs"
OUTPUT_DIR.mkdir(exist_ok=True)


def main() -> None:
    # Load the dataset.
    df = pd.read_csv(DATA_FILE)

    print("=== Student Performance Dataset ===")
    print("\nFirst 5 rows:")
    print(df.head())

    print("\nData information:")
    print(df.info())

    print("\nMissing values:")
    print(df.isnull().sum())

    print("\nData statistics:")
    print(df.describe())

    print("\nDataset shape:")
    print(df.shape)

    print("\nAverage Hours Studied:", round(df["Hours"].mean(), 2))
    print("Average Exam Score:", round(df["Score"].mean(), 2))
    print("Minimum Exam Score:", df["Score"].min())
    print("Maximum Exam Score:", df["Score"].max())

    # Save a text report for easy review/submission.
    report = OUTPUT_DIR / "exploration_report.txt"
    with report.open("w", encoding="utf-8") as file:
        file.write("STUDENT PERFORMANCE - TASK 1 EXPLORATION REPORT\n")
        file.write("=" * 52 + "\n\n")
        file.write("First 5 rows:\n")
        file.write(df.head().to_string(index=False))
        file.write("\n\nMissing values:\n")
        file.write(df.isnull().sum().to_string())
        file.write("\n\nData statistics:\n")
        file.write(df.describe().to_string())
        file.write("\n\n")
        file.write(f"Average Hours Studied: {df['Hours'].mean():.2f}\n")
        file.write(f"Average Exam Score: {df['Score'].mean():.2f}\n")
        file.write(f"Minimum Exam Score: {df['Score'].min()}\n")
        file.write(f"Maximum Exam Score: {df['Score'].max()}\n")

    # Simple exploratory visualization.
    plt.figure(figsize=(7, 5))
    plt.scatter(df["Hours"], df["Score"])
    plt.title("Hours Studied vs Exam Score")
    plt.xlabel("Hours Studied")
    plt.ylabel("Exam Score")
    plt.grid(True, alpha=0.25)
    plt.tight_layout()
    plt.savefig(OUTPUT_DIR / "hours_vs_score.png", dpi=150)
    plt.close()

    print(f"\nReport saved to: {report}")
    print(f"Plot saved to: {OUTPUT_DIR / 'hours_vs_score.png'}")


if __name__ == "__main__":
    main()
