# Project 1: Student Performance Predictor

## Task 1 — Load and Explore the Data

This project implements **Task 1** from the provided assignment brief.

### Goal

Prepare and inspect a small dataset containing:

- **Hours Studied**
- **Exam Score**

The purpose of this task is to understand the dataset before building a machine-learning model.

### Tools

- Python
- pandas
- matplotlib

The project can be run locally or in Google Colab.

## Project Structure

```text
student-performance-predictor-task1/
├── data/
│   └── student_performance.csv
├── outputs/
│   ├── exploration_report.txt
│   └── hours_vs_score.png
├── task1_explore.py
├── requirements.txt
└── README.md
```

## What Task 1 Does

The script:

1. Loads the CSV dataset with pandas.
2. Displays the first five rows using `head()`.
3. Checks the dataset structure and data types.
4. Checks for missing values.
5. Calculates basic statistics with `describe()`.
6. Displays average, minimum, and maximum values.
7. Creates a simple exploratory scatter plot of study hours vs. exam score.
8. Saves a text exploration report and plot in the `outputs` folder.

## Dataset

The dataset contains 10 sample observations of study hours and exam scores.

Example:

| Hours | Score |
|---:|---:|
| 1 | 35 |
| 2 | 45 |
| 3 | 48 |
| 4 | 52 |
| 5 | 60 |
| 6 | 68 |
| 7 | 75 |
| 8 | 82 |
| 9 | 88 |
| 10 | 95 |

The data is a small educational dataset for demonstrating the exploration task.

## Expected Statistics

For this dataset:

- Average Hours Studied: **5.50**
- Average Exam Score: **64.80**
- Minimum Exam Score: **35**
- Maximum Exam Score: **95**
- Missing values: **0**

## Installation

Python 3.9+ is recommended.

Install dependencies:

```bash
pip install -r requirements.txt
```

## Run

From the project directory:

```bash
python task1_explore.py
```

The terminal will display the first five rows, missing-value counts, descriptive statistics, and summary values.

The script also creates:

```text
outputs/exploration_report.txt
outputs/hours_vs_score.png
```

## Google Colab

Upload the project files to Google Colab, install the dependencies if needed, and run:

```python
!python task1_explore.py
```

## Task Result

The exploration shows a clear positive pattern in the sample data: as study hours increase, exam scores generally increase. This observation is useful background for later prediction/model-building tasks, but **this submission focuses only on Task 1: loading and exploring the data**.
